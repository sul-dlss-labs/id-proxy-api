The following command deletes a Cross-Origin Resource Sharing configuration from a bucket named ``my-bucket``::

  aws s3api delete-bucket-cors --bucket my-bucket
